// InsightsFeedbacks.h
//
 
//
 

#import <Foundation/Foundation.h>

@class InsightsFeedbackWidget;

extern NSString* const kInsightsFBKeyPlatform;
extern NSString* const kInsightsFBKeyAppVersion;
extern NSString* const kInsightsFBKeyWidgetID;
extern NSString* const kInsightsFBKeyID;

@interface InsightsFeedbacks : NSObject
#if (TARGET_OS_IOS)
+ (instancetype)sharedInstance;

- (void)showDialog:(void(^)(NSInteger rating))completion;
- (void)checkFeedbackWidgetWithID:(NSString *)widgetID completionHandler:(void (^)(NSError * error))completionHandler;
- (void)checkForStarRatingAutoAsk;

- (void)getFeedbackWidgets:(void (^)(NSArray <InsightsFeedbackWidget *> *feedbackWidgets, NSError *error))completionHandler;

@property (nonatomic) NSString* message;
@property (nonatomic) NSString* dismissButtonTitle;
@property (nonatomic) NSUInteger sessionCount;
@property (nonatomic) BOOL disableAskingForEachAppVersion;
@property (nonatomic, copy) void (^ratingCompletionForAutoAsk)(NSInteger);
#endif
@end
