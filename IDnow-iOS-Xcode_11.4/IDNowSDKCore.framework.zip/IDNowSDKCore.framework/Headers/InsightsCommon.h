// InsightsCommon.h
//
 
//
 

#import <Foundation/Foundation.h>
#import "Insights.h"
#import "InsightsPersistency.h"
#import "InsightsConnectionManager.h"
#import "InsightsEvent.h"
#import "InsightsUserDetails.h"
#import "InsightsDeviceInfo.h"
#import "InsightsCrashReporter.h"
#import "InsightsConfig.h"
#import "InsightsViewTracking.h"
#import "InsightsStarRating.h"
#import "InsightsNotificationService.h"
#import "InsightsConsentManager.h"
#import "InsightsLocationManager.h"
#import "InsightsRemoteConfig.h"
#import "InsightsPerformanceMonitoring.h"

#if DEBUG
#define Insights_LOG(fmt, ...) InsightsInternalLog(fmt, ##__VA_ARGS__)
#else
#define Insights_LOG(...)
#endif

#if (TARGET_OS_IOS)
#import <UIKit/UIKit.h>
#ifndef Insights_EXCLUDE_IDFA
#import <AdSupport/ASIdentifierManager.h>
#endif
#import "WatchConnectivity/WatchConnectivity.h"
#endif

#if (TARGET_OS_WATCH)
#import <WatchKit/WatchKit.h>
#import "WatchConnectivity/WatchConnectivity.h"
#endif

#if (TARGET_OS_TV)
#import <UIKit/UIKit.h>
#ifndef Insights_EXCLUDE_IDFA
#import <AdSupport/ASIdentifierManager.h>
#endif
#endif

#import <objc/runtime.h>

extern NSString* const kInsightsErrorDomain;

NS_ERROR_ENUM(kInsightsErrorDomain)
{
    INSErrorFeedbackWidgetNotAvailable = 10001,
    INSErrorFeedbackWidgetNotTargetedForDevice = 10002,
    INSErrorRemoteConfigGeneralAPIError = 10011,
};

@interface InsightsCommon : NSObject

@property (nonatomic, copy) NSString* SDKVersion;
@property (nonatomic, copy) NSString* SDKName;

@property (nonatomic) BOOL hasStarted;
@property (nonatomic) BOOL enableDebug;
@property (nonatomic) BOOL enableAppleWatch;
@property (nonatomic) BOOL enableAttribution;
@property (nonatomic) BOOL manualSessionHandling;

void InsightsInternalLog(NSString *format, ...) NS_FORMAT_FUNCTION(1,2);
void InsightsPrint(NSString *stringToPrint);

+ (instancetype)sharedInstance;
- (NSInteger)hourOfDay;
- (NSInteger)dayOfWeek;
- (NSInteger)timeZone;
- (NSInteger)timeSinceLaunch;
- (NSTimeInterval)uniqueTimestamp;

- (void)startBackgroundTask;
- (void)finishBackgroundTask;

#if (TARGET_OS_IOS || TARGET_OS_TV)
- (UIViewController *)topViewController;
- (void)tryPresentingViewController:(UIViewController *)viewController;
#endif

- (void)startAppleWatchMatching;
- (void)startAttribution;

- (void)observeDeviceOrientationChanges;

- (BOOL)hasStarted_;
@end


#if (TARGET_OS_IOS)
@interface INSInternalViewController : UIViewController
@end

@interface INSButton : UIButton
@property (nonatomic, copy) void (^onClick)(id sender);
+ (INSButton *)dismissAlertButton;
@end
#endif

@interface INSDelegateInterceptor : NSObject
@property (nonatomic, weak) id originalDelegate;
@end

@interface NSString (Insights)
- (NSString *)INS_URLEscaped;
- (NSString *)INS_SHA256;
- (NSData *)INS_dataUTF8;
@end

@interface NSArray (Insights)
- (NSString *)INS_JSONify;
@end

@interface NSDictionary (Insights)
- (NSString *)INS_JSONify;
@end

@interface NSData (Insights)
- (NSString *)INS_stringUTF8;
@end

@interface Insights (RecordReservedEvent)
- (void)recordReservedEvent:(NSString *)key segmentation:(NSDictionary *)segmentation;
- (void)recordReservedEvent:(NSString *)key segmentation:(NSDictionary *)segmentation count:(NSUInteger)count sum:(double)sum duration:(NSTimeInterval)duration timestamp:(NSTimeInterval)timestamp;
@end

@interface InsightsUserDetails (ClearUserDetails)
- (void)clearUserDetails;
@end
