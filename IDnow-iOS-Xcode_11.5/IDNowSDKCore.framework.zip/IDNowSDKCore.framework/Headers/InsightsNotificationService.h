// InsightsNotificationService.h
//
 
//
 

#import <Foundation/Foundation.h>

#if (TARGET_OS_IOS)
#import <UserNotifications/UserNotifications.h>
#endif

NS_ASSUME_NONNULL_BEGIN

extern NSString* const kInsightsActionIdentifier;

extern NSString* const kInsightsPNKeyInsightsPayload;
extern NSString* const kInsightsPNKeyNotificationID;
extern NSString* const kInsightsPNKeyButtons;
extern NSString* const kInsightsPNKeyDefaultURL;
extern NSString* const kInsightsPNKeyAttachment;
extern NSString* const kInsightsPNKeyActionButtonIndex;
extern NSString* const kInsightsPNKeyActionButtonTitle;
extern NSString* const kInsightsPNKeyActionButtonURL;

@interface InsightsNotificationService : NSObject
#if (TARGET_OS_IOS)
+ (void)didReceiveNotificationRequest:(UNNotificationRequest *)request withContentHandler:(void (^)(UNNotificationContent *))contentHandler API_AVAILABLE(ios(10.0));
#endif

NS_ASSUME_NONNULL_END

@end
